/**
 * Please Type your service description here
 * 
 */
@javax.xml.bind.annotation.XmlSchema(namespace = "http://ws.sunateo.mtpe.gob.pe", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package pe.gob.mtpe.sunateo.ws;
